/*
	Soma dois numeros inteiros.
*/

#include <stdio.h>

int main(void)
{
	int a, b, c;
	printf("a: ");
	scanf("%d", &a);
	printf("b: ");
	scanf("%d", &b);
	c = a + b;
	printf("a + b = %d\n", c);
	return 0;
}
